SELECT
    MinTemperatureF
FROM
    weather
WHERE
    zip=  94301